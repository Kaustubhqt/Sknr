-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS sneaker_haven;
USE sneaker_haven;

-- Users table: Stores user information (name, email, password)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Cart table: Stores items added to the cart
CREATE TABLE IF NOT EXISTS cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    name VARCHAR(255),
    price DECIMAL(10,2),
    image VARCHAR(255),
    size VARCHAR(10),
    quantity INT,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Products table: Stores product information (name, description, price, stock)
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    image_url VARCHAR(255),
    stock_quantity INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Orders table: Stores order details (user, total amount, order status)
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Order Items table: Stores the products within an order
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Sample data for products (replace the image URLs with actual paths)
INSERT INTO products (name, description, price, image_url, stock_quantity) VALUES
('Nike Air Max', 'Classic running shoes with air cushioning', 129.99, '/images/nike-air-max.jpg', 50),
('Adidas Ultraboost', 'Premium running shoes with boost technology', 179.99, '/images/adidas-ultraboost.jpg', 30),
('Jordan 1 Retro', 'Iconic basketball shoes', 159.99, '/images/jordan-1-retro.jpg', 25),
('New Balance 990', 'Premium lifestyle sneakers', 174.99, '/images/new-balance-990.jpg', 40),
('Puma RS-X', 'Futuristic design with comfortable cushioning', 119.99, '/images/puma-rsx.jpg', 35);

-- Insert some initial users (replace the passwords with securely hashed values)
INSERT INTO users (name, email, password) VALUES
('John Doe', 'john@example.com', 'hashedpassword123'),
('Jane Smith', 'jane@example.com', 'hashedpassword456');
 