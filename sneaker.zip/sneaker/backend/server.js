const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '9070', // Add your MySQL password here
    database: 'sneaker_store'
});

// Connect to database
db.connect((err) => {
    if (err) {
        console.error('Error connecting to database:', err);
        return;
    }
    console.log('Connected to MySQL database');
});

// Test endpoint
app.get('/', (req, res) => {
    res.json({ message: 'Server is running!' });
});

// Products API endpoints
app.get('/api/products', (req, res) => {
    db.query('SELECT * FROM products', (err, results) => {
        if (err) {
            console.error('Error fetching products:', err);
            return res.status(500).json({ error: 'Failed to fetch products' });
        }
        res.json(results);
    });
});

app.get('/api/products/:id', (req, res) => {
    const { id } = req.params;
    db.query('SELECT * FROM products WHERE id = ?', [id], (err, results) => {
        if (err) {
            console.error('Error fetching product:', err);
            return res.status(500).json({ error: 'Failed to fetch product' });
        }
        if (results.length === 0) {
            return res.status(404).json({ error: 'Product not found' });
        }
        res.json(results[0]);
    });
});

// Cart API endpoints
app.get('/api/cart', (req, res) => {
    db.query(`
        SELECT c.*, p.name, p.price, p.image 
        FROM cart c
        JOIN products p ON c.product_id = p.id
    `, (err, results) => {
        if (err) {
            console.error('Error fetching cart:', err);
            return res.status(500).json({ error: 'Failed to fetch cart' });
        }
        res.json(results);
    });
});

app.post('/api/cart', (req, res) => {
    const { product_id, size, quantity } = req.body;
    console.log('Adding to cart:', { product_id, size, quantity }); // Debug log
    
    // First check if item already exists in cart
    db.query(
        'SELECT * FROM cart WHERE product_id = ? AND size = ?',
        [product_id, size],
        (err, results) => {
            if (err) {
                console.error('Error checking cart:', err);
                return res.status(500).json({ error: 'Failed to check cart' });
            }

            if (results.length > 0) {
                // Update quantity if item exists
                const newQuantity = results[0].quantity + (quantity || 1);
                db.query(
                    'UPDATE cart SET quantity = ? WHERE id = ?',
                    [newQuantity, results[0].id],
                    (err, result) => {
                        if (err) {
                            console.error('Error updating cart:', err);
                            return res.status(500).json({ error: 'Failed to update cart' });
                        }
                        res.json({ id: results[0].id, product_id, size, quantity: newQuantity });
                    }
                );
            } else {
                // Add new item if it doesn't exist
                db.query(
                    'INSERT INTO cart (product_id, size, quantity) VALUES (?, ?, ?)',
                    [product_id, size, quantity || 1],
                    (err, result) => {
                        if (err) {
                            console.error('Error adding to cart:', err);
                            return res.status(500).json({ error: 'Failed to add to cart' });
                        }
                        res.json({ id: result.insertId, product_id, size, quantity: quantity || 1 });
                    }
                );
            }
        }
    );
});

app.put('/api/cart/:id', (req, res) => {
    const { quantity } = req.body;
    const { id } = req.params;

    db.query(
        'UPDATE cart SET quantity = ? WHERE id = ?',
        [quantity, id],
        (err, result) => {
            if (err) {
                console.error('Error updating cart:', err);
                return res.status(500).json({ error: 'Failed to update cart' });
            }
            res.json({ message: 'Cart updated successfully' });
        }
    );
});

app.delete('/api/cart/:id', (req, res) => {
    const { id } = req.params;

    db.query('DELETE FROM cart WHERE id = ?', [id], (err, result) => {
        if (err) {
            console.error('Error removing from cart:', err);
            return res.status(500).json({ error: 'Failed to remove from cart' });
        }
        res.json({ message: 'Item removed from cart' });
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something broke!' });
});

// Start server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
}); 