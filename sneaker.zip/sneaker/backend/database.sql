-- Create database
CREATE DATABASE IF NOT EXISTS sneaker_store;
USE sneaker_store;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create products table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    image VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create cart table
CREATE TABLE IF NOT EXISTS cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    product_id INT NOT NULL,
    size VARCHAR(10) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Insert sample products
INSERT INTO products (name, price, image, description) VALUES
('Nike Air Max 270', 150.00, 'images/nike-air-max-270.jpg', 'The Nike Air Max 270 delivers visible cushioning underfoot and a bold design inspired by Air Max icons.'),
('Adidas Ultraboost 22', 180.00, 'images/adidas-ultraboost-22.jpg', 'The Ultraboost 22 features responsive cushioning and a supportive fit for all-day comfort.'),
('Jordan 1 Retro High OG', 170.00, 'images/jordan-1-retro.jpg', 'The Air Jordan 1 Retro High OG is a modern take on the classic silhouette with premium materials.'),
('New Balance 990v5', 175.00, 'images/new-balance-990v5.jpg', 'The 990v5 combines premium materials with advanced cushioning technology.'); 