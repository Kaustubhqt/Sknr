// Product data
const products = [
    {
        id: 1,
        name: "Nike Air Max 270",
        price: 25000.00,
        image: "images/270.jpeg",
        description: "The Nike Air Max 270 delivers visible cushioning underfoot and a bold design inspired by Air Max icons.",
        sizes: [7, 8, 9, 10, 11, 12]
    },
    {
        id: 2,
        name: "Adidas Ultraboost 22",
        price: 18000.00,
        image: "images/ultraboost.jpeg",
        description: "The Ultraboost 22 features responsive cushioning and a supportive fit for all-day comfort.",
        sizes: [7, 8, 9, 10, 11, 12]
    },
    {
        id: 3,
        name: "Jordan 1 Retro High OG",
        price: 10000.00,
        image: "images/download.jpeg",
        description: "The Air Jordan 1 Retro High OG is a modern take on the classic silhouette with premium materials.",
        sizes: [7, 8, 9, 10, 11, 12]
    },
    {
        id: 4,
        name: "New Balance 990v5",
        price: 17605.00,
        image: "images/nb2.jpeg",
        description: "The 990v5 combines premium materials with advanced cushioning technology.",
        sizes: [7, 8, 9, 10, 11, 12]
    },
    {
        id: 5,
        name: "Puma RS-X³ Puzzle",
        price: 7000.00,
        image: "images/puma.jpeg",
        description: "The RS-X³ Puzzle features a bold design with comfortable cushioning for all-day wear.",
        sizes: [7, 8, 9, 10, 11, 12]
    },
    {
        id: 6,
        name: "Nike Dunk Low",
        price: 9000.00,
        image: "images/low dunk.jpeg",
        description: "The Nike Dunk Low returns with classic colors and premium materials.",
        sizes: [7, 8, 9, 10, 11, 12]
    }
];

// Function to create product card
function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
        <img src="${product.image}" alt="${product.name}" class="product-image">
        <div class="product-info">
            <h3 class="product-title">${product.name}</h3>
            <p class="product-price">Rs ${product.price.toFixed(2)}</p>
            <select class="size-select" id="size-${product.id}">
                <option value="">Select Size</option>
                ${product.sizes.map(size => `<option value="${size}">${size}</option>`).join('')}
            </select>
            <button class="add-to-cart" onclick="addToCart(${product.id})">Add to Cart</button>
        </div>
    `;
    return card;
}

// Function to display products
function displayProducts(productsToShow) {
    const container = document.getElementById('productsGrid') || document.getElementById('featuredProducts');
    if (!container) return;

    container.innerHTML = '';
    productsToShow.forEach(product => {
        const card = createProductCard(product);
        container.appendChild(card);
    });
}

// Function to add product to cart
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) {
        console.error('Product not found');
        return;
    }

    const sizeSelect = document.getElementById(`size-${productId}`);
    const selectedSize = sizeSelect.value;

    if (!selectedSize) {
        alert('Please select a size');
        return;
    }

    const cartItem = {
        product_id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        size: selectedSize,
        quantity: 1
    };

    // First check if the item already exists in cart
    fetch('http://localhost:3000/api/cart')
        .then(response => response.json())
        .then(cartItems => {
            const existingItem = cartItems.find(item => 
                item.product_id === product.id && item.size === selectedSize
            );

            if (existingItem) {
                // If item exists, update quantity
                return fetch(`http://localhost:3000/api/cart/${existingItem.id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        quantity: existingItem.quantity + 1
                    })
                });
            } else {
                // If item doesn't exist, add new item
                return fetch('http://localhost:3000/api/cart', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(cartItem)
                });
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            alert('Item added to cart successfully!');
            updateCartCount();
        })
        .catch(error => {
            console.error('Error adding to cart:', error);
            alert('Failed to add item to cart. Please try again.');
        });
}

// Function to update cart count
function updateCartCount() {
    fetch('http://localhost:3000/api/cart')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(cartItems => {
            const cartCount = document.getElementById('cartCount');
            if (cartCount) {
                cartCount.textContent = cartItems.length;
            }
        })
        .catch(error => {
            console.error('Error updating cart count:', error);
        });
}

// Initialize products on page load
document.addEventListener('DOMContentLoaded', () => {
    // For products page, show all products
    if (document.getElementById('productsGrid')) {
        displayProducts(products);
    }
    // For home page, show featured products (first 4)
    if (document.getElementById('featuredProducts')) {
        displayProducts(products.slice(0, 4));
    }
    // Update cart count
    updateCartCount();
});
