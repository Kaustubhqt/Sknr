const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;
const SECRET_KEY = 'your-secret-key'; // Use a stronger key in production

// Middleware
app.use(cors());
app.use(bodyParser.json());

// DB Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', // your MySQL password
    database: 'sneaker_haven'
});

db.connect((err) => {
    if (err) return console.error('DB Error:', err);
    console.log('MySQL Connected');
});

// User Registration
app.post('/api/register', (req, res) => {
    const { name, email, password } = req.body;
    bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) return res.status(500).json({ error: 'Error hashing password' });
        const sql = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';
        db.query(sql, [name, email, hashedPassword], (err) => {
            if (err) return res.status(500).json({ error: 'User registration failed' });
            res.status(200).json({ message: 'User registered successfully' });
        });
    });
});

// User Login
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    const sql = 'SELECT * FROM users WHERE email = ?';
    db.query(sql, [email], (err, results) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        if (results.length === 0) return res.status(400).json({ error: 'User not found' });

        const user = results[0];
        bcrypt.compare(password, user.password, (err, isMatch) => {
            if (err) return res.status(500).json({ error: 'Error comparing passwords' });
            if (!isMatch) return res.status(400).json({ error: 'Invalid password' });

            const token = jwt.sign({ userId: user.id }, SECRET_KEY, { expiresIn: '1h' });
            res.json({ token, userId: user.id });
        });
    });
});

// Get all products
app.get('/api/products', (req, res) => {
    db.query('SELECT * FROM products', (err, results) => {
        if (err) return res.status(500).json({ error: 'Query Failed' });
        res.json(results);
    });
});

// Add to Cart
app.post('/api/cart', (req, res) => {
    const { userId, product_id, name, price, image, size, quantity } = req.body;
    const sql = `
        INSERT INTO cart (product_id, name, price, image, size, quantity)
        VALUES (?, ?, ?, ?, ?, ?)
    `;
    db.query(sql, [product_id, name, price, image, size, quantity], (err) => {
        if (err) return res.status(500).json({ error: 'Failed to add to cart' });
        res.json({ message: 'Item added to cart' });
    });
});

// Get Cart Items
app.get('/api/cart', (req, res) => {
    const { userId } = req.query;
    const sql = 'SELECT * FROM cart WHERE user_id = ?';
    db.query(sql, [userId], (err, results) => {
        if (err) return res.status(500).json({ error: 'Failed to fetch cart items' });
        res.json(results);
    });
});

// Place an Order
app.post('/api/order', (req, res) => {
    const { userId, cartItems, totalAmount } = req.body;

    // Insert the order into the `orders` table
    const sql = 'INSERT INTO orders (user_id, total_amount) VALUES (?, ?)';
    db.query(sql, [userId, totalAmount], (err, orderResult) => {
        if (err) return res.status(500).json({ error: 'Failed to place order' });

        const orderId = orderResult.insertId;

        // Insert each item from the cart into the `order_items` table
        const orderItems = cartItems.map(item => [
            orderId,
            item.product_id,
            item.quantity,
            item.price
        ]);

        const orderItemsSql = 'INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ?';
        db.query(orderItemsSql, [orderItems], (err) => {
            if (err) return res.status(500).json({ error: 'Failed to add items to order' });

            // Update the stock quantity for each product
            cartItems.forEach(item => {
                const updateStockSql = 'UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?';
                db.query(updateStockSql, [item.quantity, item.product_id], (err) => {
                    if (err) return res.status(500).json({ error: 'Failed to update stock' });
                });
            });

            // Clear the user's cart
            const clearCartSql = 'DELETE FROM cart WHERE user_id = ?';
            db.query(clearCartSql, [userId], (err) => {
                if (err) return res.status(500).json({ error: 'Failed to clear cart' });
                res.json({ message: 'Order placed successfully' });
            });
        });
    });
});

app.listen(port, () => console.log(`Server running on http://localhost:${port}`));
