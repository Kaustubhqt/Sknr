// Authentication functionality
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const nav = document.querySelector('nav ul');

    // Add logout button to navigation if user is logged in
    const token = localStorage.getItem('token');
    if (token) {
        const logoutLi = document.createElement('li');
        logoutLi.innerHTML = '<a href="#" id="logoutBtn">Logout</a>';
        nav.appendChild(logoutLi);
        
        // Remove login and register links
        const loginLi = document.querySelector('a[href="login.html"]').parentElement;
        const registerLi = document.querySelector('a[href="register.html"]').parentElement;
        if (loginLi) loginLi.remove();
        if (registerLi) registerLi.remove();
    }

    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }

    // Add logout event listener
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            logout();
        });
    }
});

async function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    try {
        // For demo purposes, we'll use a simple check
        // In a real application, this would be an API call
        if (email && password) {
            // Store user info in localStorage
            localStorage.setItem('token', 'demo-token');
            localStorage.setItem('user', JSON.stringify({ email, name: email.split('@')[0] }));
            
            // Redirect to home page
            window.location.href = 'index.html';
        } else {
            alert('Please enter both email and password');
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('An error occurred during login');
    }
}

async function handleRegister(e) {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (password !== confirmPassword) {
        alert('Passwords do not match');
        return;
    }

    if (!name || !email || !password) {
        alert('Please fill in all fields');
        return;
    }

    try {
        // For demo purposes, we'll simulate successful registration
        // In a real application, this would be an API call
        alert('Registration successful! Please login.');
        window.location.href = 'login.html';
    } catch (error) {
        console.error('Registration error:', error);
        alert('An error occurred during registration');
    }
}

// Check if user is logged in
function checkAuth() {
    const token = localStorage.getItem('token');
    const currentPage = window.location.pathname.split('/').pop();
    
    if (!token && currentPage !== 'login.html' && currentPage !== 'register.html') {
        window.location.href = 'login.html';
    }
}

// Logout function
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('cart'); // Clear cart on logout
    window.location.href = 'login.html';
} 