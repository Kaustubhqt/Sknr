document.addEventListener('DOMContentLoaded', () => {
    console.log('Cart page loaded');
    loadCart();
    setupEventListeners();
});

function setupEventListeners() {
    const checkoutBtn = document.getElementById('checkoutBtn');
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', handleCheckout);
    }
}

function loadCart() {
    console.log('Loading cart...');
    fetch('http://localhost:3000/api/cart')
        .then(res => {
            console.log('Cart response status:', res.status);
            if (!res.ok) {
                throw new Error('Failed to fetch cart');
            }
            return res.json();
        })
        .then(cartItems => {
            console.log('Cart items received:', cartItems);
            const cartContainer = document.getElementById('cartItems');
            const subtotalElement = document.getElementById('subtotal');
            const shippingElement = document.getElementById('shipping');
            const totalElement = document.getElementById('total');

            if (!cartContainer || !subtotalElement || !shippingElement || !totalElement) {
                console.error('Required elements not found in the DOM');
                return;
            }

            cartContainer.innerHTML = '';
            let subtotal = 0;

            if (!cartItems || cartItems.length === 0) {
                console.log('Cart is empty');
                cartContainer.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
                subtotalElement.textContent = 'Rs 0.00';
                shippingElement.textContent = 'Rs 0.00';
                totalElement.textContent = 'Rs 0.00';
                return;
            }

            cartItems.forEach(item => {
                console.log('Processing cart item:', item);
                const cartItemElement = createCartItemElement(item);
                cartContainer.appendChild(cartItemElement);
                subtotal += item.price * item.quantity;
            });

            const shipping = subtotal > 0 ? 50 : 0;
            const total = subtotal + shipping;

            subtotalElement.textContent = `Rs ${subtotal.toFixed(2)}`;
            shippingElement.textContent = `Rs ${shipping.toFixed(2)}`;
            totalElement.textContent = `Rs ${total.toFixed(2)}`;
        })
        .catch(err => {
            console.error('Error loading cart:', err);
            const cartContainer = document.getElementById('cartItems');
            if (cartContainer) {
                cartContainer.innerHTML = '<p class="empty-cart">Failed to load cart items</p>';
            }
        });
}

function createCartItemElement(item) {
    console.log('Creating cart item element:', item);
    const div = document.createElement('div');
    div.className = 'cart-item';
    div.innerHTML = `
        <div class="cart-item-image">
            <img src="${item.image}" alt="${item.name}">
        </div>
        <div class="cart-item-details">
            <h3>${item.name}</h3>
            <p>Size: ${item.size}</p>
            <p>Price: Rs ${Number(item.price).toFixed(2)}</p>
            <div class="quantity-controls">
                <button onclick="updateQuantity(${item.id}, ${item.quantity - 1})">-</button>
                <span>${item.quantity}</span>
                <button onclick="updateQuantity(${item.id}, ${item.quantity + 1})">+</button>
            </div>
            <button onclick="removeFromCart(${item.id})" class="remove-btn">Remove</button>
        </div>
    `;
    return div;
}

function updateQuantity(cartItemId, newQuantity) {
    console.log('Updating quantity:', { cartItemId, newQuantity });
    if (newQuantity < 1) return;

    fetch(`http://localhost:3000/api/cart/${cartItemId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            quantity: newQuantity
        })
    })
    .then(res => {
        console.log('Update response status:', res.status);
        if (!res.ok) {
            throw new Error('Failed to update quantity');
        }
        return res.json();
    })
    .then(() => loadCart())
    .catch(err => {
        console.error('Error updating quantity:', err);
        alert('Failed to update quantity');
    });
}

function removeFromCart(cartItemId) {
    console.log('Removing cart item:', cartItemId);
    fetch(`http://localhost:3000/api/cart/${cartItemId}`, {
        method: 'DELETE'
    })
    .then(res => {
        console.log('Delete response status:', res.status);
        if (!res.ok) {
            throw new Error('Failed to remove item');
        }
        return res.json();
    })
    .then(() => loadCart())
    .catch(err => {
        console.error('Error removing item:', err);
        alert('Failed to remove item from cart');
    });
}

function handleCheckout() {
    console.log('Processing checkout');
    fetch('http://localhost:3000/api/cart/checkout', {
        method: 'POST'
    })
    .then(res => {
        console.log('Checkout response status:', res.status);
        if (!res.ok) {
            throw new Error('Checkout failed');
        }
        return res.json();
    })
    .then(() => {
        alert('Order placed successfully!');
        window.location.href = 'index.html';
    })
    .catch(err => {
        console.error('Checkout error:', err);
        alert('Something went wrong during checkout.');
    });
}
