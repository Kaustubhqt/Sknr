# Sneaker Haven E-commerce Website

A modern e-commerce website for sneakers with user authentication, product browsing, and shopping cart functionality.

## Features

- User registration and login
- Product browsing and search
- Shopping cart management
- Secure checkout process
- Responsive design

## Technologies Used

- HTML5
- CSS3
- JavaScript (ES6+)
- MySQL
- Local Storage for cart management

## Setup Instructions

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/sneaker-haven.git
   cd sneaker-haven
   ```

2. Set up the database:
   - Install MySQL if not already installed
   - Create a new database using the `database.sql` file
   - Update the database connection details in your backend code

3. Set up a local server:
   - You can use XAMPP, WAMP, or any other local server environment
   - Place the project files in the appropriate directory (e.g., htdocs for XAMPP)

4. Configure the backend:
   - Set up your backend server (Node.js, PHP, etc.)
   - Update the API endpoints in the JavaScript files to match your backend routes

5. Start the application:
   - Open your web browser
   - Navigate to `http://localhost/your-project-folder`

## Project Structure

```
sneaker-haven/
├── index.html
├── login.html
├── register.html
├── cart.html
├── css/
│   └── style.css
├── js/
│   ├── auth.js
│   └── cart.js
├── images/
│   └── (product images)
└── database.sql
```

## API Endpoints

- POST /api/register - User registration
- POST /api/login - User login
- GET /api/products - Get all products
- POST /api/checkout - Process order checkout

## Security Considerations

- Passwords are hashed before storage
- JWT tokens for authentication
- Input validation on both client and server side
- CSRF protection
- XSS prevention

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contact

Your Name - your.email@example.com

Project Link: [https://github.com/yourusername/sneaker-haven](https://github.com/yourusername/sneaker-haven) 